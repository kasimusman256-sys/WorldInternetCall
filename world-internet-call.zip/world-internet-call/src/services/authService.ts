// authService.ts
// Thin wrapper around Supabase Auth so UI components never call
// `supabase.auth.*` directly. Swappable/mockable, and keeps auth logic
// in one place.

import { supabase, isSupabaseConfigured } from "../lib/supabaseClient";
import type { AuthResult } from "../types";

export async function registerWithEmail(
  email: string,
  password: string,
  displayName: string
): Promise<AuthResult> {
  if (!isSupabaseConfigured) {
    return {
      success: false,
      errorMessage:
        "Supabase is not configured yet. Add VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY to your .env file.",
    };
  }

  const { error } = await supabase.auth.signUp({
    email,
    password,
    options: { data: { display_name: displayName } },
  });

  if (error) return { success: false, errorMessage: error.message };
  return { success: true };
}

export async function loginWithEmail(email: string, password: string): Promise<AuthResult> {
  if (!isSupabaseConfigured) {
    return {
      success: false,
      errorMessage:
        "Supabase is not configured yet. Add VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY to your .env file.",
    };
  }

  const { error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) return { success: false, errorMessage: error.message };
  return { success: true };
}

export async function logout(): Promise<void> {
  if (!isSupabaseConfigured) return;
  await supabase.auth.signOut();
}

export async function getCurrentSession() {
  if (!isSupabaseConfigured) return null;
  const { data } = await supabase.auth.getSession();
  return data.session;
}
