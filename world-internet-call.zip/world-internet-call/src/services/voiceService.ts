// voiceService.ts
//
// This is the ONLY place in the app that should know how to place a call.
// Every screen talks to the app through the `VoiceProvider` interface
// below, never directly to a calling SDK. That means swapping in the real
// Africa's Talking Voice integration later is a one-line change (see
// `getVoiceProvider` at the bottom) and touches no UI code.
//
// IMPORTANT / SAFETY NOTE:
// Africa's Talking (and any real telco voice API) requires a *secret* API
// key. That key must never live in frontend code or an env var prefixed
// with VITE_ (Vite inlines those into the shipped JS bundle, so anyone
// could read them in the browser). The real integration must call a
// backend endpoint (e.g. a Supabase Edge Function) that holds the secret
// and talks to Africa's Talking server-to-server. VITE_VOICE_BRIDGE_URL
// below is only the *public* URL of that backend endpoint.

import type { CallStatus } from "../types";

export interface CallHandle {
  callId: string;
}

export interface CallEvent {
  status: CallStatus;
  message?: string;
}

export type CallEventListener = (event: CallEvent) => void;

export interface VoiceProvider {
  /** Human-readable name, shown in the UI so it's always clear what's active. */
  readonly name: string;
  /** Whether this provider is actually able to place real calls right now. */
  readonly isLive: boolean;

  /** Start a call to `phoneNumber` (E.164 format). Emits events via `onEvent`. */
  startCall(phoneNumber: string, onEvent: CallEventListener): Promise<CallHandle>;

  /** End an in-progress call. */
  endCall(handle: CallHandle): Promise<void>;
}

/**
 * MockVoiceProvider is the safe default for this prototype.
 *
 * It deliberately does NOT simulate a successful call. It reports
 * "connecting" briefly and then reports "failed" with a clear reason,
 * because no real voice backend is connected yet. This prevents the app
 * from ever misleading a user into thinking a call went through when it
 * did not.
 */
export class MockVoiceProvider implements VoiceProvider {
  readonly name = "Prototype (no voice backend connected)";
  readonly isLive = false;

  async startCall(phoneNumber: string, onEvent: CallEventListener): Promise<CallHandle> {
    const callId = `mock-${Date.now()}`;

    onEvent({ status: "connecting", message: `Dialing ${phoneNumber}...` });

    // Small delay so the UI can honestly show a "connecting" state,
    // then report failure rather than pretending to connect.
    await new Promise((resolve) => setTimeout(resolve, 1200));

    onEvent({
      status: "failed",
      message:
        "No voice provider is connected yet. This prototype does not place real calls. " +
        "Africa's Talking Voice integration is pending (see africasTalkingVoiceProvider.ts).",
    });

    return { callId };
  }

  async endCall(_handle: CallHandle): Promise<void> {
    // Nothing to do for the mock provider.
    return;
  }
}

/**
 * AfricasTalkingVoiceProvider is a placeholder for the future real
 * integration. It intentionally throws until it's implemented, so it can
 * never be accidentally used to fake a working call.
 *
 * Implementation plan for later:
 * 1. Deploy a backend endpoint (e.g. Supabase Edge Function) that holds
 *    the Africa's Talking API key as a server-side secret.
 * 2. That endpoint calls Africa's Talking's Voice API to initiate a call
 *    and returns a call/session id.
 * 3. Use Africa's Talking's callback/webhook mechanism (or polling) to
 *    receive real status updates, and forward them into `onEvent` here.
 * 4. Set VITE_VOICE_BRIDGE_URL to that endpoint's public URL.
 */
export class AfricasTalkingVoiceProvider implements VoiceProvider {
  readonly name = "Africa's Talking Voice";
  readonly isLive = true;

  private readonly bridgeUrl: string;

  constructor(bridgeUrl: string) {
    this.bridgeUrl = bridgeUrl;
  }

  async startCall(_phoneNumber: string, _onEvent: CallEventListener): Promise<CallHandle> {
    throw new Error(
      `AfricasTalkingVoiceProvider is not implemented yet. ` +
        `Bridge URL configured as: ${this.bridgeUrl || "(none set)"}`
    );
  }

  async endCall(_handle: CallHandle): Promise<void> {
    throw new Error("AfricasTalkingVoiceProvider is not implemented yet.");
  }
}

/**
 * Single place that decides which provider the app uses.
 * Today this always returns the mock provider, on purpose, until the
 * Africa's Talking integration above is finished and tested.
 */
export function getVoiceProvider(): VoiceProvider {
  return new MockVoiceProvider();

  // Once AfricasTalkingVoiceProvider is implemented, switch over with:
  //
  // const bridgeUrl = import.meta.env.VITE_VOICE_BRIDGE_URL;
  // return bridgeUrl
  //   ? new AfricasTalkingVoiceProvider(bridgeUrl)
  //   : new MockVoiceProvider();
}
