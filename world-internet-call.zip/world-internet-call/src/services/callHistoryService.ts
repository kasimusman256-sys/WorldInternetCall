// callHistoryService.ts
// Reads/writes call records. Falls back to in-memory/local mock data
// when Supabase isn't configured yet, so the UI is fully explorable
// without a backend.

import { supabase, isSupabaseConfigured } from "../lib/supabaseClient";
import type { CallRecord } from "../types";

const LOCAL_KEY = "wic_mock_call_history";

function readLocalHistory(): CallRecord[] {
  try {
    const raw = localStorage.getItem(LOCAL_KEY);
    return raw ? (JSON.parse(raw) as CallRecord[]) : [];
  } catch {
    return [];
  }
}

function writeLocalHistory(records: CallRecord[]): void {
  try {
    localStorage.setItem(LOCAL_KEY, JSON.stringify(records));
  } catch {
    // ignore storage errors (e.g. private browsing)
  }
}

export async function getRecentCalls(userId: string): Promise<CallRecord[]> {
  if (!isSupabaseConfigured) {
    return readLocalHistory().filter((r) => r.userId === userId);
  }

  const { data, error } = await supabase
    .from("call_records")
    .select("*")
    .eq("user_id", userId)
    .order("started_at", { ascending: false })
    .limit(20);

  if (error || !data) return [];
  return data as unknown as CallRecord[];
}

export async function addCallRecord(record: CallRecord): Promise<void> {
  if (!isSupabaseConfigured) {
    const history = readLocalHistory();
    history.unshift(record);
    writeLocalHistory(history.slice(0, 50));
    return;
  }

  await supabase.from("call_records").insert({
    id: record.id,
    user_id: record.userId,
    phone_number: record.phoneNumber,
    status: record.status,
    started_at: record.startedAt,
    ended_at: record.endedAt,
    duration_seconds: record.durationSeconds,
    failure_reason: record.failureReason,
  });
}
