import React, { createContext, useContext, useEffect, useMemo, useState } from "react";
import { isSupabaseConfigured, supabase } from "../lib/supabaseClient";
import type { UserProfile } from "../types";

const LOCAL_USER_KEY = "wic_mock_user";

interface AuthContextValue {
  user: UserProfile | null;
  loading: boolean;
  backendConnected: boolean;
  setMockUser: (user: UserProfile) => void;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!isSupabaseConfigured) {
      // Prototype mode: restore a locally-stored mock session, if any.
      try {
        const raw = localStorage.getItem(LOCAL_USER_KEY);
        if (raw) setUser(JSON.parse(raw) as UserProfile);
      } catch {
        // ignore
      }
      setLoading(false);
      return;
    }

    supabase.auth.getSession().then(({ data }) => {
      const session = data.session;
      if (session?.user) {
        setUser({
          id: session.user.id,
          email: session.user.email ?? "",
          displayName: (session.user.user_metadata?.display_name as string) ?? null,
          creditsBalance: 0,
          createdAt: session.user.created_at,
        });
      }
      setLoading(false);
    });

    const { data: sub } = supabase.auth.onAuthStateChange((_event, session) => {
      if (session?.user) {
        setUser({
          id: session.user.id,
          email: session.user.email ?? "",
          displayName: (session.user.user_metadata?.display_name as string) ?? null,
          creditsBalance: 0,
          createdAt: session.user.created_at,
        });
      } else {
        setUser(null);
      }
    });

    return () => sub.subscription.unsubscribe();
  }, []);

  const setMockUser = (newUser: UserProfile) => {
    setUser(newUser);
    try {
      localStorage.setItem(LOCAL_USER_KEY, JSON.stringify(newUser));
    } catch {
      // ignore
    }
  };

  const signOut = async () => {
    if (isSupabaseConfigured) {
      await supabase.auth.signOut();
    } else {
      localStorage.removeItem(LOCAL_USER_KEY);
    }
    setUser(null);
  };

  const value = useMemo(
    () => ({ user, loading, backendConnected: isSupabaseConfigured, setMockUser, signOut }),
    [user, loading]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within an AuthProvider");
  return ctx;
}
