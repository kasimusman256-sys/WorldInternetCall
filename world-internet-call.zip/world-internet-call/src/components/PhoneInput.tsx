import React from "react";

const COUNTRY_CODES = [
  { code: "+1", label: "US/CA (+1)" },
  { code: "+44", label: "UK (+44)" },
  { code: "+254", label: "Kenya (+254)" },
  { code: "+255", label: "Tanzania (+255)" },
  { code: "+256", label: "Uganda (+256)" },
  { code: "+234", label: "Nigeria (+234)" },
  { code: "+233", label: "Ghana (+233)" },
  { code: "+27", label: "South Africa (+27)" },
  { code: "+91", label: "India (+91)" },
  { code: "+61", label: "Australia (+61)" },
];

interface Props {
  countryCode: string;
  number: string;
  onCountryCodeChange: (code: string) => void;
  onNumberChange: (number: string) => void;
  disabled?: boolean;
}

export default function PhoneInput({
  countryCode,
  number,
  onCountryCodeChange,
  onNumberChange,
  disabled,
}: Props) {
  return (
    <div className="phone-input">
      <select
        className="phone-input__code"
        value={countryCode}
        onChange={(e) => onCountryCodeChange(e.target.value)}
        disabled={disabled}
        aria-label="Country code"
      >
        {COUNTRY_CODES.map((c) => (
          <option key={c.code} value={c.code}>
            {c.label}
          </option>
        ))}
      </select>
      <input
        className="phone-input__number"
        type="tel"
        inputMode="tel"
        placeholder="712 345 678"
        value={number}
        disabled={disabled}
        onChange={(e) => onNumberChange(e.target.value.replace(/[^0-9]/g, ""))}
        aria-label="Phone number"
      />
    </div>
  );
}

export function toE164(countryCode: string, number: string): string {
  return `${countryCode}${number}`.replace(/\s+/g, "");
}
