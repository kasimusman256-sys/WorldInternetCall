import React from "react";

export default function CreditsDisplay({ credits }: { credits: number }) {
  return (
    <div className="credits-card">
      <span className="credits-card__label">Credits</span>
      <span className="credits-card__value">{credits.toFixed(2)}</span>
    </div>
  );
}
