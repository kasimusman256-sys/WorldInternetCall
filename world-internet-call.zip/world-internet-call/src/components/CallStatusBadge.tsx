import React from "react";
import type { CallStatus } from "../types";

const LABELS: Record<CallStatus, string> = {
  idle: "Ready",
  ready: "Ready",
  connecting: "Connecting...",
  in_progress: "In Progress",
  ended: "Ended",
  failed: "Failed",
};

export default function CallStatusBadge({ status }: { status: CallStatus }) {
  return <span className={`status-badge status-badge--${status}`}>{LABELS[status]}</span>;
}
