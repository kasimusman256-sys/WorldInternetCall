import React from "react";
import type { CallRecord } from "../types";
import CallStatusBadge from "./CallStatusBadge";

export default function RecentCalls({ calls }: { calls: CallRecord[] }) {
  if (calls.length === 0) {
    return <p className="muted">No calls yet. Your recent calls will show up here.</p>;
  }

  return (
    <ul className="call-list">
      {calls.map((call) => (
        <li key={call.id} className="call-list__item">
          <div>
            <div className="call-list__number">{call.phoneNumber}</div>
            <div className="muted small">
              {new Date(call.startedAt).toLocaleString()}
            </div>
          </div>
          <CallStatusBadge status={call.status} />
        </li>
      ))}
    </ul>
  );
}
