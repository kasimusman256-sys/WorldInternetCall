// Core domain types shared across the app.

export type CallStatus =
  | "idle"        // no call in progress
  | "ready"       // number entered, ready to dial
  | "connecting"  // dial initiated, waiting on voice provider
  | "in_progress" // call is live
  | "ended"       // call finished normally
  | "failed";     // call could not be completed

export interface UserProfile {
  id: string;
  email: string;
  displayName: string | null;
  creditsBalance: number; // in whole "credits" units, not currency
  createdAt: string;
}

export interface CallRecord {
  id: string;
  userId: string;
  phoneNumber: string;   // E.164 format, e.g. +14155551234
  status: CallStatus;
  startedAt: string;
  endedAt: string | null;
  durationSeconds: number | null;
  failureReason: string | null;
}

export interface AuthResult {
  success: boolean;
  errorMessage?: string;
}
