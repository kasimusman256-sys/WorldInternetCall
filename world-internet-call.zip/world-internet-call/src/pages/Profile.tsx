import React from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function Profile() {
  const { user, signOut, backendConnected } = useAuth();
  const navigate = useNavigate();

  if (!user) return null;

  async function handleLogout() {
    await signOut();
    navigate("/");
  }

  return (
    <div className="profile-screen">
      <div className="avatar-large">{(user.displayName ?? user.email).slice(0, 1).toUpperCase()}</div>
      <h2>{user.displayName ?? "No name set"}</h2>
      <p className="muted">{user.email}</p>

      <div className="profile-info">
        <div className="profile-info__row">
          <span>Credits</span>
          <span>{user.creditsBalance.toFixed(2)}</span>
        </div>
        <div className="profile-info__row">
          <span>Account created</span>
          <span>{new Date(user.createdAt).toLocaleDateString()}</span>
        </div>
        <div className="profile-info__row">
          <span>Backend</span>
          <span>{backendConnected ? "Supabase connected" : "Prototype (local only)"}</span>
        </div>
      </div>

      <button className="btn btn--danger" onClick={handleLogout}>
        Log out
      </button>
    </div>
  );
}
