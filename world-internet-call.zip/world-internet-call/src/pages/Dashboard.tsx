import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import PhoneInput, { toE164 } from "../components/PhoneInput";
import CallStatusBadge from "../components/CallStatusBadge";
import CreditsDisplay from "../components/CreditsDisplay";
import RecentCalls from "../components/RecentCalls";
import { getVoiceProvider } from "../services/voiceService";
import { addCallRecord, getRecentCalls } from "../services/callHistoryService";
import type { CallRecord, CallStatus } from "../types";

export default function Dashboard() {
  const { user } = useAuth();
  const [countryCode, setCountryCode] = useState("+1");
  const [number, setNumber] = useState("");
  const [status, setStatus] = useState<CallStatus>("idle");
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [calls, setCalls] = useState<CallRecord[]>([]);
  const provider = getVoiceProvider();

  useEffect(() => {
    if (!user) return;
    getRecentCalls(user.id).then(setCalls);
  }, [user]);

  if (!user) return null;

  const canCall = number.trim().length >= 4 && status !== "connecting" && status !== "in_progress";

  async function handleCall() {
    const phoneNumber = toE164(countryCode, number);
    setStatus("connecting");
    setStatusMessage(null);

    const startedAt = new Date().toISOString();
    const record: CallRecord = {
      id: `call-${Date.now()}`,
      userId: user!.id,
      phoneNumber,
      status: "connecting",
      startedAt,
      endedAt: null,
      durationSeconds: null,
      failureReason: null,
    };

    let lastStatus: CallStatus = "connecting";
    let lastMessage: string | null = null;

    await provider.startCall(phoneNumber, (event) => {
      lastStatus = event.status;
      lastMessage = event.message ?? null;
      setStatus(event.status);
      setStatusMessage(event.message ?? null);
    });

    const finalRecord: CallRecord = {
      ...record,
      status: lastStatus,
      endedAt: new Date().toISOString(),
      durationSeconds: 0,
      failureReason: lastStatus === "failed" ? lastMessage : null,
    };

    await addCallRecord(finalRecord);
    const refreshed = await getRecentCalls(user!.id);
    setCalls(refreshed);
  }

  return (
    <div className="dashboard">
      <header className="dashboard__header">
        <div>
          <p className="muted small">Welcome back</p>
          <h2>{user.displayName ?? user.email}</h2>
        </div>
        <Link to="/profile" className="avatar-link" aria-label="Profile">
          {(user.displayName ?? user.email).slice(0, 1).toUpperCase()}
        </Link>
      </header>

      <CreditsDisplay credits={user.creditsBalance} />

      {!provider.isLive && (
        <p className="notice">
          {provider.name}: real calls are not enabled yet. This is a safe prototype &mdash;
          it will never claim a call connected unless a real voice backend is wired up.
        </p>
      )}

      <section className="call-card">
        <PhoneInput
          countryCode={countryCode}
          number={number}
          onCountryCodeChange={setCountryCode}
          onNumberChange={setNumber}
          disabled={status === "connecting" || status === "in_progress"}
        />

        <button
          className="call-button"
          onClick={handleCall}
          disabled={!canCall}
          aria-label="Call"
        >
          <PhoneIcon />
        </button>

        <div className="call-card__status">
          <CallStatusBadge status={status === "idle" ? "ready" : status} />
          {statusMessage && <p className="muted small call-card__message">{statusMessage}</p>}
        </div>
      </section>

      <section>
        <h3>Recent calls</h3>
        <RecentCalls calls={calls} />
      </section>
    </div>
  );
}

function PhoneIcon() {
  return (
    <svg width="32" height="32" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path
        d="M6.6 10.8c1.4 2.8 3.8 5.1 6.6 6.6l2.2-2.2c.3-.3.7-.4 1-.2 1.1.4 2.3.6 3.6.6.6 0 1 .4 1 1V20c0 .6-.4 1-1 1C10.4 21 3 13.6 3 4c0-.6.4-1 1-1h3.5c.6 0 1 .4 1 1 0 1.2.2 2.5.6 3.6.1.4 0 .8-.2 1L6.6 10.8z"
        fill="currentColor"
      />
    </svg>
  );
}
