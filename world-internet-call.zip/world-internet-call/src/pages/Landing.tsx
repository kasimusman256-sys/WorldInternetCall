import React from "react";
import { Link } from "react-router-dom";

export default function Landing() {
  return (
    <div className="landing">
      <div className="landing__glow" />
      <div className="landing__content">
        <div className="logo-mark">WIC</div>
        <h1>World Internet Call</h1>
        <p className="landing__tagline">
          Call any number, anywhere, straight from the app.
        </p>
        <div className="landing__actions">
          <Link to="/register" className="btn btn--primary">Get Started</Link>
          <Link to="/login" className="btn btn--ghost">I already have an account</Link>
        </div>
        <p className="muted small landing__note">
          Prototype build &mdash; calling backend not yet connected.
        </p>
      </div>
    </div>
  );
}
