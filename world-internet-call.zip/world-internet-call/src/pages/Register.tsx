import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { registerWithEmail } from "../services/authService";

export default function Register() {
  const navigate = useNavigate();
  const { backendConnected, setMockUser } = useAuth();
  const [displayName, setDisplayName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setSubmitting(true);

    if (backendConnected) {
      const result = await registerWithEmail(email, password, displayName);
      setSubmitting(false);
      if (!result.success) {
        setError(result.errorMessage ?? "Registration failed.");
        return;
      }
      navigate("/dashboard");
      return;
    }

    // Prototype mode: no backend, create a local mock account.
    setMockUser({
      id: `mock-${Date.now()}`,
      email,
      displayName: displayName || email.split("@")[0],
      creditsBalance: 10,
      createdAt: new Date().toISOString(),
    });
    setSubmitting(false);
    navigate("/dashboard");
  }

  return (
    <div className="auth-screen">
      <h1>Create your account</h1>
      {!backendConnected && (
        <p className="notice">Prototype mode: no backend connected yet. Your account is stored on this device only.</p>
      )}
      <form onSubmit={handleSubmit} className="form">
        <label className="field">
          <span>Name</span>
          <input value={displayName} onChange={(e) => setDisplayName(e.target.value)} required />
        </label>
        <label className="field">
          <span>Email</span>
          <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
        </label>
        <label className="field">
          <span>Password</span>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            minLength={6}
            required
          />
        </label>
        {error && <p className="error">{error}</p>}
        <button type="submit" className="btn btn--primary" disabled={submitting}>
          {submitting ? "Creating account..." : "Create account"}
        </button>
      </form>
      <p className="muted small">
        Already have an account? <Link to="/login">Log in</Link>
      </p>
    </div>
  );
}
