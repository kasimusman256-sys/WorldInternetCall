import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { loginWithEmail } from "../services/authService";

export default function Login() {
  const navigate = useNavigate();
  const { backendConnected, setMockUser } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setSubmitting(true);

    if (backendConnected) {
      const result = await loginWithEmail(email, password);
      setSubmitting(false);
      if (!result.success) {
        setError(result.errorMessage ?? "Login failed.");
        return;
      }
      navigate("/dashboard");
      return;
    }

    // Prototype mode: accept any credentials and create a local mock session.
    setMockUser({
      id: `mock-${Date.now()}`,
      email,
      displayName: email.split("@")[0],
      creditsBalance: 10,
      createdAt: new Date().toISOString(),
    });
    setSubmitting(false);
    navigate("/dashboard");
  }

  return (
    <div className="auth-screen">
      <h1>Welcome back</h1>
      {!backendConnected && (
        <p className="notice">Prototype mode: no backend connected yet. Any email/password will sign you in locally.</p>
      )}
      <form onSubmit={handleSubmit} className="form">
        <label className="field">
          <span>Email</span>
          <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
        </label>
        <label className="field">
          <span>Password</span>
          <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
        </label>
        {error && <p className="error">{error}</p>}
        <button type="submit" className="btn btn--primary" disabled={submitting}>
          {submitting ? "Logging in..." : "Log in"}
        </button>
      </form>
      <p className="muted small">
        Don&apos;t have an account? <Link to="/register">Sign up</Link>
      </p>
    </div>
  );
}
