import { createClient, type SupabaseClient } from "@supabase/supabase-js";

const url = import.meta.env.VITE_SUPABASE_URL;
const anonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

// isSupabaseConfigured lets the rest of the app detect "no backend wired
// up yet" and behave gracefully instead of crashing on a missing key.
export const isSupabaseConfigured = Boolean(url && anonKey && !url.includes("your-project-ref"));

// A single shared client. If env vars are missing we still create a
// harmless placeholder client so imports never throw at module load time;
// callers should check isSupabaseConfigured before relying on it.
export const supabase: SupabaseClient = createClient(
  url || "https://placeholder.supabase.co",
  anonKey || "placeholder-anon-key"
);
